CREATE DATABASE IF NOT EXISTS presidential_voting CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE presidential_voting;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS election (
  id TINYINT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  is_open TINYINT(1) NOT NULL DEFAULT 1,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL
);

CREATE TABLE IF NOT EXISTS candidates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  party VARCHAR(100) NOT NULL,
  slogan VARCHAR(200) NOT NULL DEFAULT '',
  bio TEXT NULL,
  color CHAR(7) NOT NULL DEFAULT '#1d4ed8'
);

CREATE TABLE IF NOT EXISTS voters (
  id INT AUTO_INCREMENT PRIMARY KEY,
  voter_id VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  pin_hash VARCHAR(255) NOT NULL,
  has_voted TINYINT(1) NOT NULL DEFAULT 0,
  voted_at DATETIME NULL
);

-- Secret ballot: no link to the voter. Receipt lets a voter confirm their ballot was counted.
CREATE TABLE IF NOT EXISTS votes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  candidate_id INT NOT NULL,
  receipt CHAR(12) NOT NULL UNIQUE,
  cast_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);
